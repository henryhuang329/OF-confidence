function [f_err, density] = compute_roc_dt(F_gt, F_est, tau, im1)
%%
% find outliers by thresholding the forward and backward flow inconsistency

[E_org,F_val] = flow_error_map (F_gt,F_est);

nValid = length(find(F_val));
T = [1 2 3 4 5 10 100 1000 1e4];

sigmaxy = 32;
sigmargb=32;
sigmadt = 2;
niters = 3;

dt = RF(F_est, sigmaxy, sigmargb, niters, im1);
dt2 = RF(F_est.^2, sigmaxy, sigmargb, niters, im1);

V = dt2 - dt.^2;
V = mean(V(:,:,1:2), 3);

V = max(0, V); % variance should be no less than 0

V = exp(-V/2/sigmadt^2);

% T = [0 logspace(-2, 0, 10)];
T = linspace(0, 1, 11);
for i=1:numel(T)            
    E = E_org;
    % do not count those above the threshold
    E(V<T(i)) = 0;    
    f_err(i)   = sum((E(:)>tau))/nValid;
    density(i) = sum(F_val(:)~=0 & V(:)>= T(i))/nValid;
    %density(i) = sum(F_val(count(:)<= T(i))~=0)/nValid;
end

