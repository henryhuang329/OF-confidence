function [f_err, density] = compute_roc_fb(F_gt, F_est, F_est_b, tau, isFixedPerc)
%%
% find outliers by thresholding the forward and backward flow inconsistency

[E_org,F_val] = flow_error_map (F_gt,F_est);

[incon, OOB] =  compute_fb_inconsistency(F_est, F_est_b); 

if nargin >=5 && isFixedPerc
    pcts = 0:0.1:1;
    T = prctile2(incon(~OOB), pcts);
% T = prctile(incon(F_val~=0), pcts*100);    
else
    T = [0.5 1 2 5 max(incon(:))+1];
end

nValid = length(find(F_val));
for i=1:numel(T)        
    E = E_org;
    % do not count those above the threshold
    E(incon>T(i)) = 0;
    f_err(i) = sum((E(:)>tau))/nValid;    
    density(i) = sum(incon(F_val~=0) <=T(i))/nValid;
end