% function compute_confidence_roc_curves
%%
tau = 3;
nFrames = 194;
linewidth = 2;
fontsize  = 15; 
%% Forward-backward
isFixedPerc = false;
if isFixedPerc
    evalType = 'fixed_prectage';
else
    evalType = 'fixed_threshold';
end

clear F_err_fb den_fb
for r = 0:1:20; nFrames-1
    fprintf('%d\n', r);
    data = load_data_NVEnc_opitcal_flow(r);
    F_err_gt(r+1, :) = compute_roc_gt(data.uvt, data.uv, tau);    
    [F_err_fb(r+1, :), den_fb(r+1,:)] = compute_roc_fb(data.uvt, data.uv, data.uvb, tau, isFixedPerc);    
    
    %[F_err_mu(r+1, :), den_mu(r+1,:)] = compute_roc_fb(data.uvt, data.uv, data.uvb, tau, isFixedPerc);    
%     F_err_bce(r+1, :) = compute_roc_bce(data.uvt, data.uv, data.im1, data.im2, tau);
end
%%
figure;

plot(0:0.1:1, mean(F_err_gt, 1), '-o', 'linewidth', linewidth); 
hold on;
 
plot(mean(den_fb, 1), mean(F_err_fb, 1), 'g-+', 'linewidth', linewidth);
% plot(0:0.1:1, mean(F_err_bce, 1), 'g-+', 'linewidth', linewidth); 

title('ROC (EPE > 3)', 'fontsize', fontsize);
xlabel('Percetage of remaining pixels', 'fontsize', fontsize);
ylabel('Error rate', 'fontsize', fontsize)

legend({'GT', 'FB'}, 'location', 'best', 'fontsize', fontsize);

%legend({'GT', 'FB', 'BCE'}, 'location', 'best', 'fontsize', fontsize);

% figure; hist(den_fb(:,4), 20);
%
fn = fullfile('result', sprintf('fb_%s.mat', evalType));
save(fn, 'F_err_gt', 'F_err_fb', 'den_fb');
fn = fullfile('result', sprintf('fb_%s2.png', evalType));
saveas(gcf, fn, 'png');

%% load and plot results by FB (over 194 sequences)
evalType = 'fixed_threshold';
% evalType = 'fixed_prectage';
fn = fullfile('result', sprintf('fb_%s.mat', evalType));
load(fn)
plot(mean(den_fb, 1), mean(F_err_fb, 1), 'r-*', 'linewidth', linewidth);
% legend({'GT', 'Algorithm I', 'Algorithm II'}, 'location', 'best', 'fontsize', fontsize);
% fn = fullfile('result', 'overlaid.png');
% saveas(gcf, fn, 'png');

%%
clear F_err_mu den_mu
for r = 0:1:nFrames-1
    fprintf('%d\n', r);
    data = load_data_NVEnc_opitcal_flow(r);    
    [F_err_mu(r+1, :), den_mu(r+1,:)] = compute_roc_mu(data.uvt, data.uv, tau);    
    % F_err_bce(r+1, :) = compute_roc_bce(data.uvt, data.uv, data.im1, data.im2, tau);
end
% figure; plot(0:0.1:1, mean(F_err_bce, 1), 'g-+', 'linewidth', linewidth); 
figure; plot(mean(den_mu,1), mean(F_err_mu, 1), 'g-+', 'linewidth', linewidth);  
hold on;

legend({'map uniqueness', 'FB'}, 'location', 'best', 'fontsize', fontsize);

fn = fullfile('result', sprintf('mu.mat', evalType));
save(fn, 'F_err_mu','den_mu');

fn = fullfile('result', 'fb_mu.png');
saveas(gcf, fn, 'png');

%% domain transform
clear F_err_dt den_dt
for r = 0:1:nFrames-1
    fprintf('%d\n', r);
    data = load_data_NVEnc_opitcal_flow(r);    
    [F_err_dt(r+1, :), den_dt(r+1,:)] = compute_roc_dt(data.uvt, data.uv, tau, data.im1);    
    % F_err_bce(r+1, :) = compute_roc_bce(data.uvt, data.uv, data.im1, data.im2, tau);
end
% figure; plot(0:0.1:1, mean(F_err_bce, 1), 'g-+', 'linewidth', linewidth); 
figure; plot(mean(den_dt,1), mean(F_err_dt, 1), 'g-+', 'linewidth', linewidth);  
hold on;
% if exist('den_fb', 'var')
%     plot(mean(den_fb, 1), mean(F_err_fb, 1), 'r-*', 'linewidth', linewidth);
% end

legend({'DT', 'FB'}, 'location', 'best', 'fontsize', fontsize);

fn = fullfile('result', sprintf('dt_var.mat', evalType));
save(fn, 'F_err_dt','den_dt');

fn = fullfile('result', 'fb_dt_var.png');
saveas(gcf, fn, 'png');