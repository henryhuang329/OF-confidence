% function compute_confidence_roc_curves
%%
tau = 3;
nFrames = 194;
linewidth = 2;
fontsize  = 15; 
%%
% clear F_err_fb den_fb
for r = 0:1:nFrames-1;
    fprintf('%d\n', r);
    data = load_data_NVEnc_opitcal_flow(r);
    F_err_gt(r+1, :) = compute_roc_gt(data.uvt, data.uv, tau);    
    [F_err_fb(r+1, :), den_fb(r+1,:)] = compute_roc_fb(data.uvt, data.uv, data.uvb, tau);        
    [F_err_dt(r+1, :), den_dt(r+1,:)] = compute_roc_dt(data.uvt, data.uv, tau, data.im1);    
    [F_err_mu(r+1, :), den_mu(r+1,:)] = compute_roc_mu(data.uvt, data.uv, tau);    
end
%%
figure;
plot(0:0.1:1, mean(F_err_gt, 1), '-o', 'linewidth', linewidth); hold on;
plot(mean(den_fb, 1), mean(F_err_fb, 1), 'g-+', 'linewidth', linewidth);
plot(mean(den_dt,1), mean(F_err_dt, 1), 'r-*', 'linewidth', linewidth);  
plot(mean(den_mu,1), mean(F_err_mu, 1), 'b-+', 'linewidth', linewidth);  
legend({'GT', 'FB', 'DT', 'MU'}, 'location', 'best', 'fontsize', fontsize);
%%
fn = fullfile('result', 'eval.mat');
save(fn, 'F_err_gt', 'F_err_fb', 'den_fb', 'F_err_dt', 'den_dt', 'F_err_mu', 'den_mu');

fn = fullfile('result', 'eval.png');
saveas(gcf, fn, 'png');

