function area = compute_roc_area(F, den)
%%
area = sum((F(1:end-1)+F(2:end))/2.*abs(den(2:end)-den(1:end-1)));
