function [f_err, density] = compute_roc_mu(F_gt, F_est, tau)
%%
% find outliers by thresholding the forward and backward flow inconsistency

[E_org,F_val] = flow_error_map (F_gt,F_est);

nValid = length(find(F_val));
T = [1 2 3 4 5 10 100 1000];

%%% include both occluding and occluded pixels
[occ, count] = reason_occlusion_mp(F_est);

for i=1:numel(T)            
    E = E_org;
    % do not count those above the threshold
    E(count>T(i)) = 0;    
    f_err(i)   = sum((E(:)>tau))/nValid;
    density(i) = sum(F_val(:)~=0 & count(:)<= T(i))/nValid;
    %density(i) = sum(F_val(count(:)<= T(i))~=0)/nValid;
end

% for debug
% E = E_org;
% E(occ==0) = 0;
% f_err = [f_err sum((E(:)>tau))/nValid];
% density = [density sum(F_val(:)~=0 & occ(:)==1)/nValid];



% occ = reason_occlusion_mp(F_est);
% nValid = length(find(F_val));
% E = E_org;
% % do not count those above the threshold
% E(occ==0) = 0;
% f_err = sum((E(:)>tau))/nValid;
% density = sum(F_val(:)~=0 & occ(:)==1)/nValid;
