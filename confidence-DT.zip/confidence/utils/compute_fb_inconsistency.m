function [incon, OOB] =  compute_fb_inconsistency(uv, uvb, method)
%%
% compute uv + uv_b(x+d, y+v)

%method = 'cubic';
% method = 'linear';
if nargin <3
    method = 'nearest';
end

H   = size(uv, 1);
W   = size(uv, 2);

[x,y]   = meshgrid(1:W,1:H);
x2      = x + uv(:,:,1);        
y2      = y + uv(:,:,2);  

% out-of-boundary pixels
OOB = (x2>W) | (x2<1) | (y2>H) | (y2<1);

x2(OOB) = x(OOB);
y2(OOB) = y(OOB);


inv_u = interp2(x,y,uvb(:,:,1),x2,y2,method);
inv_v = interp2(x,y,uvb(:,:,2),x2,y2,method);

incon = abs(uv(:,:,1)+inv_u) + abs(uv(:,:,2)+inv_v);

% TO DISCUSS: ignore out-of-boundary pixels
incon(OOB) = 0;
