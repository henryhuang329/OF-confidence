function f_err = compute_roc_bce(F_gt, F_est, im1, im2, tau)
%%
% find outliers by thresholding the forward and backward flow inconsistency

[E_org,F_val] = flow_error_map (F_gt,F_est);

aIt = abs(compute_partial_deriv(cat(3, im1, im2), F_est));

pcts = 0:0.1:1;

% T = prctile2(aIt(:), pcts);
T = prctile2(aIt(F_val~=0), pcts);
% T = prctile(aIt(:), pcts*100);
% T = prctile(aIt(F_val~=0), pcts*100);

nValid = length(find(F_val));
for i=1:numel(pcts)        
    E = E_org;
    % do not count those above the threshold
    E(aIt>T(i)) = 0;
    f_err(i) = sum((E(:)>tau))/nValid;    
end