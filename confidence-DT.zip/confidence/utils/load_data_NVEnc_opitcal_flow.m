function data = load_data_NVEnc_opitcal_flow(iFrame)
%%
addpath(genpath('utils'));

metaDir = 'C:\Users\deqings\Documents\Data\stereo_of_data';
if ~exist(metaDir, 'file');
    metaDir = '\\netapp-ma\public\stereo_of_data\';
end

dataDir = fullfile(metaDir, 'NVEnc\4m4fb1.0');

% first frame
fn = fullfile(dataDir, 'image', sprintf('%06d_10.png', iFrame));
data.im1 = double(imread(fn));
% second frame
fn = fullfile(dataDir, 'image', sprintf('%06d_11.png', iFrame));
data.im2 = double(imread(fn));

% gt optical flow
gtDir = fullfile(metaDir, '\data_stereo_flow\training\flow_noc');
fn = fullfile(gtDir, sprintf('%06d_10.png', iFrame));
data.uvt = flow_read_kitti(fn);

dataDir = fullfile(metaDir, 'NVEnc\fbInData'); 

% NVEnc optical flow
fn = fullfile(dataDir, 'data', sprintf('%06d_10_small.png', iFrame));
data.uvsmall = flow_read_kitti(fn);
% NVEnc + median
fn = fullfile(dataDir, 'data', sprintf('%06d_10_median.png', iFrame));
if exist(fn, 'file')
    data.uvmedian = flow_read_kitti(fn);
else
    for i=1:size(data.uvsmall,3); 
        data.uvmedian(:,:,i) = medfilt2(data.uvsmall(:,:,i), [5 5], 'symmetric');
    end
end


% backward flow field
fn = fullfile(dataDir, 'data', sprintf('%06d_10_small_B.png', iFrame));
data.uvsmall_b = flow_read_kitti(fn);
% NVEnc + median
fn = fullfile(dataDir, 'data', sprintf('%06d_10_median_B.png', iFrame));
if exist(fn, 'file')
    data.uvmedian_b = flow_read_kitti(fn);
else
    for i=1:size(data.uvsmall,3); 
        data.uvmedian_b(:,:,i) = medfilt2(data.uvsmall_b(:,:,i), [5 5], 'symmetric');
    end
end



% [H,W, ~] = size(data.uvt);
% % NVEnc + median + upsampling
% % TO CHECK: no need to scale the flow field
% data.uv = imresize(data.uvmedian, [H, W], 'bilinear', 'Antialiasing', false); 
% data.uvb = imresize(data.uvmedian_b, [H, W], 'bilinear', 'Antialiasing', false);

% Modifiation by Henry Huang

[H,W, ~] = size(data.uvt);
[Hs, Ws, ~] = size(data.uvmedian);
% NVEnc + median + upsampling
% TO CHECK: no need to scale the flow field
data.uvFull = imresize(data.uvmedian, [Hs*4, Ws*4], 'bilinear', 'Antialiasing', false); 
data.uvbFull = imresize(data.uvmedian_b, [Hs*4, Ws*4], 'bilinear', 'Antialiasing', false);
data.uv = data.uvFull(1:H,1:W,:);
data.uvb = data.uvbFull(1:H,1:W,:);


