function tune_dt_parameters
%% tune parameters of dt by minimizing the ROC area (approximated)
tau = 3;
nFrames = 194;

niters = 3;

Sigmaxy = 12; %6*[0.75 1.25]; %*[0.5 1 2];
Sigmargb= 128; %64*[1.5 2 2.5]; %64*[0.5 1 2];
Sigmadt = 2;
% minArea = 1;
% minParams = [32 32 2];

tic
for sigmaxy = Sigmaxy
    for sigmargb = Sigmargb
        for sigmadt = Sigmadt
            for r = 0:1:nFrames-1;
                data = load_data_NVEnc_opitcal_flow(r);
                [F_err_dt(r+1, :), den_dt(r+1,:)] = compute_roc_dt(data.uvt, data.uv, tau, data.im1...
                    , sigmaxy, sigmargb, sigmadt, niters);
            end
            
            area = compute_roc_area(mean(F_err_dt, 1), mean(den_dt,1));            
            fprintf('%.6f\n', area);
            if area < minArea
                minArea = area;
                minParams = [sigmaxy sigmargb sigmadt];
                min_Ferr_dt = F_err_dt;
                min_den_dt  = den_dt;
            end
        end
    end;
end
toc
minParams

%%
fn = fullfile('result', 'eval.mat');
if exist(fn, 'file')
    load(fn);
else
    compute_confidence_roc_curves;
end

figure;
plot(0:0.1:1, mean(F_err_gt, 1), '-o', 'linewidth', linewidth); hold on;
plot(mean(den_fb, 1), mean(F_err_fb, 1), 'g-+', 'linewidth', linewidth);
plot(mean(min_den_dt,1), mean(min_Ferr_dt, 1), 'r-*', 'linewidth', linewidth);  
plot(mean(den_mu,1), mean(F_err_mu, 1), 'b-+', 'linewidth', linewidth);  
legend({'GT', 'FB', 'DT', 'MU'}, 'location', 'best', 'fontsize', fontsize);

fn = fullfile('result', 'eval_tuned_dt.png');
saveas(gcf, fn, 'png');

fn = fullfile('result', 'tuned_dt.mat');
save(fn, 'min_den_dt', 'min_Ferr_dt', 'minParams', 'minArea');

%% number of iterations

Niters = 1:10;

sigmaxy = 32;
sigmargb= 32;
sigmadt = 2;
minArea = 1;
minParams = [32 32 2];

tic
for niters = Niters
    
    for r = 0:1:nFrames-1;
        data = load_data_NVEnc_opitcal_flow(r);
        [F_err_dt(r+1, :), den_dt(r+1,:)] = compute_roc_dt(data.uvt, data.uv, tau, data.im1...
            , sigmaxy, sigmargb, sigmadt, niters);
    end
    
    area = compute_roc_area(mean(F_err_dt, 1), mean(den_dt,1));
    fprintf('%d\t%.6f\n', niters, area);
    if area < minArea
        minArea = area;
        minParams = niters;
        min_Ferr_dt = F_err_dt;
        min_den_dt  = den_dt;
    end
end
toc