function y  = prctile2(x, prts)
%%
N = numel(x(:));

x = sort(x(:), 'ascend');

prts = min(N, max(1, round(prts*N)));

y = x(prts);
