function f_err = compute_roc_gt(F_gt, F_est, tau)
%%
[E_org,F_val] = flow_error_map(F_gt,F_est);

% Ecs = cumsum(E_org(:));

pcts = 0:0.1:1;

T = prctile2(E_org(F_val~=0), pcts);

% T = prctile(E_org(:), pcts*100);
nValid = length(find(F_val));
for i=1:numel(pcts)        
    E = E_org;
    % do not count those above the threshold
    E(E>T(i)) = 0;
    %f_err(i) = length(find(E>tau))/nValid;    
    f_err(i) = sum((E(:)>tau))/nValid;    
end